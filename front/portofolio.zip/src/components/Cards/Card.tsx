import "./Card.css";
const Card = () => {
  return <div className="Card"></div>;
};

export default Card;
