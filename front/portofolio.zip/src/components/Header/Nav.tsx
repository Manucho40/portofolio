import { useState } from "react";
import { Link } from "react-router-dom";

const Nav = () => {
  const [active, setActive] = useState<string>("/");

  return (
    <ul className="nav">
      <li onClick={() => setActive("/")}>
        <Link
          to="/"
          style={active === "/" ? { color: "white" } : { color: "gray" }}
        >
          Accueil
        </Link>
      </li>
      <li onClick={() => setActive("apropos")}>
        <Link
          to="/apropos"
          style={active === "apropos" ? { color: "white" } : { color: "gray" }}
        >
          Apropos
        </Link>
      </li>
      <li onClick={() => setActive("portofolio")}>
        <Link
          to="/portofolio"
          style={
            active === "portofolio" ? { color: "white" } : { color: "gray" }
          }
        >
          Portofolio
        </Link>
      </li>
      <li onClick={() => setActive("contact")}>
        <Link
          to="/contact"
          style={active === "contact" ? { color: "white" } : { color: "gray" }}
        >
          Contact
        </Link>
      </li>
    </ul>
  );
};

export default Nav;
