import { Link } from "react-router-dom";
import "./Header.css";
import { useState } from "react";
import Nav from "./Nav";

const Header = () => {
  return (
    <header>
      <div>
        <h1 className="logo">KaeDev</h1>
      </div>
      <Nav />
      <div className="containerButton">
        <a href="#">Me contacter</a>
      </div>
    </header>
  );
};

export default Header;
