import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Col } from "antd";
import "./IconeCircle.css";
type Props = {
  valueIcon: any;
};
const IconeCircle = ({ valueIcon }: any) => {
  return (
    <a href="#" className="IconHover">
      <FontAwesomeIcon icon={valueIcon} size="3x" />
    </a>
  );
};

export default IconeCircle;
