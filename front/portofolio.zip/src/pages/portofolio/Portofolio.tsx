import React, { useState } from "react";
import "./Portofolio.css";
const Portofolio = () => {
  const [typeProject, setTypeProject] = useState<string>("All");

  console.log(typeProject);
  return (
    <div className="Portofolio">
      <ul>
        <li className="typeProject">
          <button
            onClick={() => setTypeProject("All")}
            className={typeProject === "All" ? "projectSelected" : ""}
          >
            All
          </button>
        </li>
        <li className="typeProject">
          <button
            onClick={() => setTypeProject("Web")}
            className={typeProject === "Web" ? "projectSelected" : ""}
          >
            Web
          </button>
        </li>
        <li className="typeProject">
          <button
            onClick={() => setTypeProject("Mobile")}
            className={typeProject === "Mobile" ? "projectSelected" : ""}
          >
            Mobile
          </button>
        </li>
      </ul>
      <div></div>
    </div>
  );
};

export default Portofolio;
